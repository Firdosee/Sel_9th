import time

from Config.config import Test_Data
from Pages.Login_Page import Login_Page
from Pages.Logout_Page import Logout_Page
from Pages.Profile_Page import Profile_Page
from Testscripts.test_Base import test_Base


class Test_Logout(test_Base):

    def test_add_logout_functionality(self):
        log = test_Base.getLogger()
        self.login_6 = Login_Page(self.driver)
        self.login_6.base_login_to_application()
        self.logout = Logout_Page(self.driver)
        self.logout.logout_operation()
        log.info("Testcase6 is successfully passed")
