import time

from Config.config import Test_Data
from Pages.Grocery_Page import Grocery_Page
from Pages.Login_Page import Login_Page
from Testscripts.test_Base import test_Base
from Testscripts.test_Login import Test_Loginn


class Test_Cart(test_Base):

    def test_cart_functionality(self):
        log = test_Base.getLogger()
        self.login_1 = Login_Page(self.driver)
        self.login_1.base_login_to_application()
        self.home = Grocery_Page(self.driver)
        self.home.click_operation(self.home.GROCERY)
        log.info("Navigating to Grocery Section")
        self.home.implicit_waiting()
        data = self.home.get__data("test_Cart_Functionality")
        self.home.Hover_operation(self.home.Staples)
        self.home.click_operation(self.home.Add_Toor_Daal)
        self.home.click_operation(self.home.Add_gujrati_daal)
        # t = Test_Data()
        data_dict_2 = Test_Data.getTestData(self, "test_Cart_Functionality")
        # product1= data_dict_2["Staples"].format{}
        log.info("Adding product 1")
        a = int(1)
        self.home.Switch_to_child_window(a)
        self.home.click_operation(self.home.Add_to_basket)
        self.home.Hover_operation(self.home.Dairy)
        self.home.click_operation(self.home.Cheese)
        self.home.click_operation(self.home.Add_amul_cheese)
        log.info("Adding product2")
        b = int(2)
        self.home.Switch_to_child_window(b)
        self.home.click_operation(self.home.Add_to_basket)
        self.home.Hover_operation(self.home.Snacks)
        self.home.click_operation(self.home.Cookies)
        self.home.click_operation(self.home.Unibic)
        log.info("Adding product 3")
        c = int(3)
        self.home.Switch_to_child_window(c)
        self.home.click_operation(self.home.Add_to_basket)
        self.home.click_operation(self.home.Go_to_basket)
        flag = self.home.is_text_present(str(data_dict_2["Cookies"]))
        log.info(flag)
        assert True == flag
        flag = self.home.is_text_present(str(data_dict_2["Dairy"]))
        print(type(data_dict_2["Dairy"]))
        log.info(flag)
        assert True == flag
        flag = self.home.is_text_present(str(data_dict_2["Staples"]))
        log.info(flag)
        assert True == flag
        log.info("All 3 items are successfully added into basket")
        self.home.Switch_to_child_window(a)
        self.home.click_operation(self.home.Go_To_Cart)
        flag = self.home.is_text_present(str(data_dict_2["quantity_in_cart"]))
        log.info("All 3 items are successfully added into Cart")
        log.info("Second testcase is passed")
