import time

from Config.config import Test_Data
from Pages.Login_Page import Login_Page
from Pages.Profile_Page import Profile_Page
from Testscripts.test_Base import test_Base


class Test_Address(test_Base):

    def test_add_address_functionality(self):
        log = test_Base.getLogger()
        self.login_5 = Login_Page(self.driver)
        self.login_5.base_login_to_application()
        self.profile = Profile_Page(self.driver)
        self.profile.navigate_to_address()
        self.profile.click_operation(self.profile.ADD_ADDRESS)
        log.info("Adding New Address...")
        data_dict_5 = Test_Data.getTestData(self, "add_address")
        log.info("Adding Name...")
        self.profile.send_keys_operation(self.profile.NAME, str(data_dict_5["Address_name"]))
        log.info("Adding phone number...")
        self.profile.send_keys_operation(self.profile.PHONE, str(data_dict_5["Address_phone"]))
        log.info("Adding pincode...")
        self.profile.send_keys_operation(self.profile.PINCODE, str(data_dict_5["pincode"]))
        log.info("Adding locality...")
        self.profile.send_keys_operation(self.profile.LOCALITY, str(data_dict_5["locality"]))
        log.info("Adding area...")
        self.profile.send_keys_operation(self.profile.ADDRESS, str(data_dict_5["area"]))
        log.info("Checking radio button...")
        self.profile.click_operation(self.profile.HOME_CHECKBOX)
        log.info("Saving changes...")
        self.profile.click_operation(self.profile.SAVE_BUTTON)
        log.info("Saved changes successfully!!")
        res = self.profile.element_exist_check(self.profile.Assertion_Element)
        assert res == True
        log.info("New Address has been added successfully!!")
        log.info("Testcase5 is passed successfully!!!")


