import time

from Config.config import Test_Data
from Pages.Fashion_Page import Fashion_Page
from Pages.Grocery_Page import Grocery_Page
from Pages.Login_Page import Login_Page
from Pages.WishList_Page import WishList_Page
from Testscripts.test_Base import test_Base
from Testscripts.test_Login import Test_Loginn


class Test_Wishlist(test_Base):

    def test_wishlist_functionality(self):
        log = test_Base.getLogger()
        self.login_4 = Login_Page(self.driver)
        self.login_4.base_login_to_application()
        data_dict_3 = Test_Data.getTestData(self, "test_wishlist")
        self.fashion = Fashion_Page(self.driver)
        log.info("Navigating to Fashion Section")
        self.fashion.Hover_operation(self.fashion.Fashion)
        self.fashion.Hover_operation(self.fashion.Kids)
        log.info("Inside the Kids Section")
        self.fashion.click_operation(self.fashion.Girls_Dresses)
        self.fashion.click_operation(self.fashion.dress1)
        self.fashion.Hover_operation(self.fashion.Women_Ethnic)
        self.fashion.click_operation(self.fashion.Women_Sarees)
        log.info("Inside the Saree Section")
        self.fashion.click_operation(self.fashion.saree1)
        self.wish = WishList_Page(self.driver)
        self.wish.go_to_wishlist()
        dress_kid = self.wish.is_text_present(str(data_dict_3["kids_dress1"]))
        assert dress_kid == True
        log.info("Kids dress is added into wishlist successfully")
        dress_saree = self.wish.is_text_present(str(data_dict_3["women_saree_1"]))
        assert dress_saree == True
        log.info("Saree is added into wishlist successfully")
        log.info("Test Case 3 is passed successfully")

